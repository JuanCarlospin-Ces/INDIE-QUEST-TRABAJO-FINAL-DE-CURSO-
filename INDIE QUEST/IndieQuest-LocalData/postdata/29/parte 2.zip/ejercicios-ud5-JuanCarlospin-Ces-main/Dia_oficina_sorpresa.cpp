#include <iostream>
#include <cmath>
using namespace std;

/**
 * @brief Imprime un vector de enteros (que se pasa por referencia por defecto)
 * @param vector[] (E) vector de int
 * @param util_vector (E) cantidad de elementos utilizados en el vector
 * @pre util_vector <= DIM_VECTOR y util_vector >= 0
 * @post Se queda impreso por pantalla el vector de ints
 */
void imprime_vector_enteros(int vector[], int util_vector){
    cout << "Vector = { ";
    for(int i = 0; i < util_vector; i++){
        cout << vector[i] << " ";
    }
    cout << "}"<< endl;
}

/**
 * @brief Imprime un vector de doubles (que se pasa por referencia por defecto)
 * @param vector[] (E) vector de doubles
 * @param util_vector (E) cantidad de elementos utilizados en el vector
 * @pre util_vector <= DIM_VECTOR y util_vector >= 0
 * @post Se queda impreso por pantalla el vector de doubles
 */
void imprime_vector_double(const double vector[], int util_vector){
    cout << "Vector = { ";
    for(int i = 0; i < util_vector; i++){
        cout << vector[i] << " ";
    }
    cout << "}"<< endl;
}

/**
 * @brief Módulo que dobla la cantidad de elementos de un vector de doubles
 * 
 * @param vector (E/S) vector de double
 * @param util_vector (E) cantidad de elementos utilizados en el vector
 * @pre util_vector <= DIM_VECTOR y util_vector >= 0
 * @post Se ha multiplicado por 2 cada uno de los elementos del vector
 */
void doblar_cantidad_vector(double vector[], int util_vector){
    for (int i = 0; i < util_vector; i++){
        vector[i] = vector[i] * 2;
    }
}

/**
 * @brief Módulo que pide al usuario un numero entero y lo registra
 * @param vector dimensión
 * @pre valor>0 || valor<= DIM_VECTOR
 */
int pedir_valor_entero (int dim_vector, int DIM_NOTAS) {

    int numerito;
    do{
        cout << "¿Cuántos alumnos hay vivos todavía? (MAXIMO:" << DIM_NOTAS << ")" << endl;
        cin >> numerito;
    }while(numerito <= 0 || numerito > DIM_NOTAS);
    //post: alumnos_vivos > 0 y alumnos_vivos <= DIM_NOTAS

    return numerito;
}

/** Pide que el usuario introduzca las notas de los alumnos
 * 
 */
int pedir_notas_alumno(int util, int alumnos_vivos, double notas) {

    util= 0;
    for (int i = 0; i < alumnos_vivos; i++ ) {
        cout << "Nota del alumno " << (i + 1) << ": ";
        cin >> notas[i];
        util++;
    }
//post: util_notas = alumnos_vivos;
    return util;
}

int main() {
    const int DIM_NOTAS = 20; //define la dimensión del vector
    const int DIM_COPIA_NOTAS = DIM_NOTAS;
    int util_notas = 0; //controla en cada momento la cantidad de componentes utilizadas en el vector
    //pre: util_notas < DIM_NOTAS y util_notas >= 0
    //pre: DIM_NOTAS > 0
    int i = 0;
    double notas[DIM_NOTAS], media = 0.0, sumatoria = 0.0, desviacion = 0.0;
    int alumnos_vivos;

    double copia_notas[DIM_COPIA_NOTAS];
    int util_copia_notas = 0;

    alumnos_vivos=pedir_valor_entero(alumnos_vivos,DIM_NOTAS);
    pedir_notas_alumno(util_notas, alumnos_vivos,notas[]);


    //MEDIA____________________________________
    for (i = 0; i < util_notas; i++ ) {
        media = notas[i] + media;
        //cout << notas[i] << endl;
    }
    media = media / util_notas;

    //DESVIACIÓN TÍPICA________________________
    for (i = 0; i < util_notas; i++){
        sumatoria = (pow((notas[i] - media), 2));
        //cout << notas[i] << endl;
    }
    desviacion = sqrt (sumatoria / (util_notas));


    cout << "Media = " << media << endl;
    cout << "Desviación típica = " << desviacion << endl;


    //COPIAR EL VECTOR DE NOTAS
    for (util_copia_notas = 0; util_copia_notas < util_notas; util_copia_notas++){
        copia_notas[util_copia_notas] = notas[util_copia_notas];
    }
    cout << "Vector copia de notas" << endl;
    imprime_vector_double(copia_notas, util_copia_notas);
    doblar_cantidad_vector(copia_notas, util_copia_notas);
    cout << "Vector copia de notas doblado" << endl;
    imprime_vector_double(copia_notas, util_copia_notas);


}