//
//  ejemplovectoresmodulos.cpp
//
//
//  Created by Jaime Matas Bustos on 11/1/17.
//  Modified by Juan Carlos Pinar Ferreira on 04/02/2025
//

#include <iostream>
#include <iomanip>
#define RESTORE "\033[1;0m"
#define DEBUG "\033[1;31m"
#define USER "\033[1;34m"
using namespace std;


/**************************************************************************************
************************************** PROTOTIPOS *************************************
**************************************************************************************/

//-------------------------------------- BACK ---------------------------------------------

/**
 * @brief Modulo que ordena un vector siguiendo el algoritmo de ordenación por Burbuja.
 * @param int vector[], int &util_vector
 * @return vector de entrada ordenado.
 */
void ordenacionBurbuja(int vector[], int &util_vector);

/**
 * @brief Modulo que ordena un vector siguiendo el algoritmo de ordenación por Insercion.
 * @param int vector[], int &util_vector
 * @return vector de entrada ordenado.
 */
void ordenarPorInsercion (int vector[], int &util_vector);

/**
 * @brief Modulo que ordena un vector siguiendo el algoritmo de ordenación por Seleccion.
 * @param int vector[], int &util_vector
 * @return vector de entrada ordenado.
 */
void ordenacionSeleccion(int vector[], int &util_vector);

/**
 * @brief Modulo que ordena los valores de 2 vectores de entrada y los devuelve en un vector de salida.
 * @pre Los vectores de entrada deben estar ordenados.
 * @return Un vector de salida, con los valores de ambos vectores de entrada ordenados.
 */
void ordenarDosVectoresOrdenados(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int vector_ordenado[], int &util_vector_ordenado);

/**
 * @brief Modulo que realiza una busqueda secuencial de un vector, devolviendo la posición del valor buscado.
 * @param int numero_a_buscar, int vector[], int &util_vector, int posicion
 * @return Posicion del elemento buscando en el vector
 * @post Si no se encuentra el valor, se devuelve la posición -1
 */
int busquedaSecuencialDeUnVector(int numero_a_buscar, int vector[], int &util_vector, int posicion);

/**
 * @brief Módulo que realiza el calculo de la moda de un vector de enteros. 
 * @param int vector[], int &util_vector
 * @return valor de la variable de tipo int moda
 */
int calculoModaDeUnVector(int vector[], int &util_vector);

/**
 * @brief Verifica si hay espacio restante en un vector o no.
 * @param util_vector, DIM_VECTOR
 * @return True si hay espacio, False si no.
 */
bool hayEspacio(int &util_vector, const int DIM_VECTOR);

/** @brief Verifica si un elemento de un vector es par o no.
 * @param Elemento vector
 * @return True si es par, False si no.
 * 
 */
bool esElementoVectorPar(int numero);

/**
 * @brief Módulo que calcula sí un numero introducido es primo o no.
 * @param n Número ENTERO/tipo int. 
 * @pre n>0
 * @return Booleano. True=Si es primo, y False= si no es primo.
 * @post
 * @version 1.0
 */ 
bool calculoPrimo (int numero);

/**
 * @brief Módulo para agregar un entero a la última posición de un vector.
 * @param int vector_salida[],int &util_vector_salida, int elemento_entrada
 * @pre.
 * @post El elemento se agrega al final del vector y util_vector se incrementa en 1.
 */
void agregarEnteroAlFinalDelVector(int vector_salida[],int &util_vector_salida, int elemento_entrada);

/** 
 * @brief Módulo que verifica si el elemento de un vector es igual al siguiente elemento [i+1].
 * @param vector[], util_vector
 * @pre util_vector >= 1
 * @return False si no se repite el elemento.
 * @return True si se repite el elemento. 
 */
bool verificarSiElementoSeRepiteContiguamente(int n, int m);

/**
 * @brief Modulo que calcula cual es el mayor valor entre 2 enteros.
 * @ int n, int m
 * @return El mayor de los 2 enteros.
 */
int calculoMayorEntreDosNumeros(int n, int m);

/**
 * @brief Modulo que intercambia los valores entre 2 vectores de enteros.
 * @param int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2.
 * @return Ambos modulos 1 y 2, con sus valores intercambiados entre si.
 */
void intercambiarDosVectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

//-------------------------------------- CONTROLADORES ------------------------------------

/**
 * @brief Módulo controlador, que imprime en pantalla un vector de entrada desordenado, y seguido, el mismo ordenado siguiendo el algoritmo de ordenación de la burbuja.
 * @param int vector[], int &util_vector
 * @return Impreso en pantalla el vector desordenado y ordenado.
 */
void controladorMetodoBurbuja(int vector[], int &util_vector);

/**
 * @brief Módulo controlador, que imprime en pantalla un vector de entrada desordenado, y seguido, el mismo ordenado siguiendo el algoritmo de ordenación de Seleccion.
 * @param int vector[], int &util_vector
 * @return Impreso en pantalla el vector desordenado y ordenado.
 */
void controladorOrdenarSeleccion (int vector[], int &util_vector);

/**
 * @brief Módulo controlador, que imprime en pantalla un vector de entrada desordenado, y seguido, el mismo ordenado siguiendo el algoritmo de ordenación de Inserción.
 * @param int vector[], int &util_vector
 * @return Impreso en pantalla el vector desordenado y ordenado.
 */
void controladorOrdenarPorInsercion(int vector[], int &util_vector);

/**
 * @brief Módulo controlador que llama las funciones necesarias para ordenar dos vectores ordenados. Imprime en pantalla los 2 vectores de entrada, y uno de salida que contiene los valores de los 2 vectores de entrada ordenados.
 * @param int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2) 
 * @return Impreso en pantalla los vectores de entrada y el de salida ordenado.
 * 
 */
void ejercicioOrdenarDosVectoresOrdenados(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/** 
 * @brief Modulo que pide al usuario que introduzca un valor, el cual se buscara en el vector introducido como parametro.
 * @param int vector[], int &util_vector
 * @return El vector impreso en pantalla, número introducido y su posicion correspondiente, comenzando a partir de la posicion 0.
 * @post Caso no este, se devolvera la posicion 0
 */
void RealizarBusquedaSecuencial(int vector[], int &util_vector);

/** @brief Modulo que permite el usuario seleccionar al usuario que ejercicio realizar.
 *  @param Vector, Util del vector, Dimensiones (Vectores 1 y 2).
 *  @return Realización del ejercicio seleccionado por el usuario
 */
void seleccionEjercicioaRealizar(int vector[],int &util_vector, const int DIM_VECTOR, int vector2[], int &util_vector2, int DIM_VECTOR2);


/**
 * @brief Modulo que llama una serie de otros modulos para agregar un elemento a un vector Entero 
 * @param vector, util_vector, DIM_VECTOR
 * @return Si hay espacio, permite que el usuario introduzca otro entero. 
 */
void ejercicioAgregarEntero(int vector[],int &util_vector, const int DIM_VECTOR);

/** 
 * @brief Módulo que elimina elementos que se repiten contiguamente en un vector1, e imprime en el vector 2 los elementos sin repeticiones contiguas. También imprime ambos vectores en la pantalla.
 EJEMPLO:
 ENTRADA v = { 1 1 1 2 2 3 3 ? ? ? ? ... ? } util = 7 DIM_VECTOR = 2000 
 SALIDA  v = { 1 2 3 ? ? ? ... ? } util = 3 DIM_VECTOR = 2000
 * @param int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2
 * @return Devuelve el vector2, donde se han imprimido los elementos no repetidos del vector1.
 */
void ejercicioEliminarRepetidosContiguos( int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2 );


/**
 * @brief Módulo que realiza el ejercicio de copiar los elementos del vector de entrada en el vector de salida. Dependiendo del caso, ejecutara ordenes diferentes.
 * @param vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2int vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2
 * @return Vector 2 copiado.
 */
void ejercicioCopiarVectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/**
 * @brief Módulo que realiza el ejercicio de copiar los elementos PARES del vector de entrada en el vector de salida. Dependiendo del caso, ejecutara ordenes diferentes.
 * @param vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2int vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2
 * @return Pares en el vector 2.
 */
void ejercicioCopiarPares(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/**
 * @brief Módulo que realiza el ejercicio de copiar los elementos PRIMOS del vector de entrada en el vector de salida. Dependiendo del caso, ejecutara ordenes diferentes.
 * @param vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2int vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2
 * @return Primos en el vector 2.
 */
void ejercicioCopiarPrimos(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/**
 * @brief Módulo que copia los valores del vector de entrada en el vector de salida.
 * @param vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2int vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2
 * @return Vector 2 copiado.
 */
void copiarVectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/**
 * @brief Módulo que copia los valores PARES de un vector de entrada a uno de salida.
 * @param vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2int vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2
 * @return Pares copiados en el vector 2.
 */
void copiarPares(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/**
 * @brief Módulo que copia los valores PRIMOS de un vector de entrada a uno de salida.
 * @param vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2int vector1[], vector2[], &util_vector1, &util_vector2, DIM_VECTOR1, DIM_VECTOR2
 * @return Primos copiados en el vector 2.
 */
void copiarPrimos(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/**
 * @brief Módulo que elimina los elementos repetidos contiguamente de un vector 1, pasando a un vector 2 los elementos sin repetirse.
 * @param int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2
 * @return vector2, que es igual a vector 1 sin los elementos repetidos de manera contigua.
 */
void eliminaElementosRepetidosContiguamenteDeUnVector(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2);

/**
 * @brief Modulo que imprime por pantalla dos vectores, y si ambos poseen espacio suficiente, intercambia el contenido de los dos, imprimiendolos en pantalla despues de hacer el intercambio.
 * @param int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2 
 * @return Contenido de los dos vectores intercambiado, impreso por pantalla.
 */
void ejercicioIntercambiarContenidosDOSvectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2 );

/**
 * @brief Módulo que imprime en pantalla un vector, y a seguir, imprime en pantalla su Moda. 
 * EJEMPLO:
  ENTRADA v = { 1 1 1 2 2 2 2 2 3 3 } 
  SALIDA  "La moda del vector es { 2 }"
 * @pre El módulo, por ahora, solo es capaz de devolver una moda.
 * @return Impreso en pantalla un vector y su moda.
 */
void ejercicioCalcularModaDeUnVector(int vector[],int  &util_vector);

//--------------------------------------- FRONT ------------------------------------------------------

/** @brief Imprime menu del programa.
 *  @post Se imprime por pantalla el menu.
 */
void imprimirMenu();

/**
 * @brief Módulo que imprime en pantalla la moda de un vector, en el caso que exista apenas una.
 * @param int numero
 * @return "La moda del vector es { numero }"
 */
void imprimeModa(int numero);

/**
 * @brief Módulo que agrega un nuevo número entero en el vector de enteros, al final de las componentes utilizadas.
 EJEMPLO:
 ENTRADA v = { 4 2 7 ? ? ? ? ... ? } util = 3 DIM_VECTOR = 2000 entero = 3
 SALIDA  v = { 4 2 7 3 ? ? ? ... ? } util = 4 DIM_VECTOR = 2000 entero = 3
 
 * @pre El número entero que queremos insertar está filtrado.
 * @param vector Es una referencia al vector de números enteros. Al ser un módulo de escritura y lectura del vector, lo paso como referencia SIN constante.
 * @param util_vector Es la variable que contiene las componentes utilizadas/ocupadas actualmente en el vector. Se pasa por REFERENCIA porque SÍ se va a cambiar el número de componentes utilizadas en el vector.
 * @param DIM_VECTOR Es la constante que me indica la DIMENSIÓN del vector, esto es el número máximo de componentes que podré utilizar. Es fijo y no se puede alterar.
 * @param entero Es el nuevo número entero que quiero insertar en el vector.
 */
void agregarNuevoEnteroenVectorEnteros(int vector[], int &util_vector, const int DIM_VECTOR, int entero);


/**
 * @brief Módulo que imprimirá por pantalla un vector de enteros.
 * @param vector Es una referencia al vector de números enteros. Al ser un módulo de sólo lectura del vector, lo paso como referencia constante.
 * @param util_vector Es la variable que contiene las componentes utilizadas/ocupadas actualmente en el vector. Se pasa por COPIA porque NO se va a cambiar el número de componentes utilizadas en el vector.
 * @post Se imprimirá por la pantalla de la consola el contenido del vector.
 */
void imprimeVectorEnteros(const int vector[], int util_vector);

/**
 * @brief Módulo que dobla el valor de cada componente del vector de enteros.
 *    Ejemplo: ENTRADA: v = { 4 2 7 } SALIDA: v = { 8 4 14 }
 * @param vector Es una referencia al vector de números enteros. Al ser un módulo de escritura y lectura del vector, lo paso como referencia SIN constante.
 * @param util_vector Es la variable que contiene las componentes utilizadas/ocupadas actualmente en el vector. Se pasa por COPIA porque NO se va a cambiar el número de componentes utilizadas en el vector.
 * @pre util_vector deberá ser >=0 y < DIM_VECTOR
 * @post El vector cambiará sus valores y serán el doble.
 * @author
 * @version
 */
void doblarValoresDelVectorEnteros(int vector[], int util_vector);


//***************************** MAIN ******************************************************

int main(){

    const int DIM_VECTOR = 100;
    const int DIM_VECTOR2 = 100;

    int vector[DIM_VECTOR] = {7, 2, -1, 4, 3 }; 
    int vector2[DIM_VECTOR2] = {-2, -1, 4, 5, 6, 7, 8};
    int util_vector = 5; 
    int util_vector2= 7;
    int selector = 0; 
    
    imprimirMenu();
    seleccionEjercicioaRealizar(vector,util_vector, DIM_VECTOR, vector2, util_vector2, DIM_VECTOR2);
    
}



//*******************************************************************************************

//---------------------------------------------------------------------------------------------------
//-                                             MODULOS                                             -
//---------------------------------------------------------------------------------------------------

void imprimirMenu(){

    cout<<"----------------------------------------------------------------------------------------------"<<endl;
    cout<<"Bienvenido usuario. Elija el ejercicio que desea ejecutar, introduciendo su respectivo numero. "<<endl;
    cout<<"[1] Agregar elemento al vector."<<endl;
    cout<<"[2] Copiar vector de entrada en salida."<<endl;
    cout<<"[3] Copiar elementos pares."<<endl;
    cout<<"[4] Copiar elementos primos."<<endl;
    cout<<"[5] ELiminar elementos repetidos contiguos."<<endl;
    cout<<"[6] Intercambiar contenido de dos vectores."<<endl;
    cout<<"[7] Calcular la moda de un vector entero. (Básico)"<<endl;
    cout<<"[8] Ordenar dos vectores ordenados."<<endl;
    cout<<"[-1] Realizar busqueda secuencial de un vector"<<endl;
    cout<<"[-2] Ordenar un vector por seleccion."<<endl;
    cout<<"[-3] Ordenar un vector por nsercion."<<endl;
    cout<<"[-4] Ordenar un vector por método de la burbuja."<<endl;    

}

void seleccionEjercicioaRealizar(int vector[],int &util_vector, const int DIM_VECTOR, int vector2[], int &util_vector2, int DIM_VECTOR2){

    int selector=0;
    cin>>selector;

    switch (selector) {

        case 1:
            ejercicioAgregarEntero(vector,util_vector, DIM_VECTOR);
            break;

        case 2:
            ejercicioCopiarVectores(vector, vector2, util_vector, util_vector2, DIM_VECTOR, DIM_VECTOR2);
            break;

        case 3:
            ejercicioCopiarPares(vector, vector2, util_vector, util_vector2, DIM_VECTOR, DIM_VECTOR2);
            break;

        case 4:
            ejercicioCopiarPrimos(vector, vector2, util_vector, util_vector2, DIM_VECTOR, DIM_VECTOR2);
            break;

        case 5: 
            ejercicioEliminarRepetidosContiguos(vector, vector2, util_vector, util_vector2, DIM_VECTOR, DIM_VECTOR2);
            break;

        case 6:
            ejercicioIntercambiarContenidosDOSvectores(vector, vector2, util_vector, util_vector2, DIM_VECTOR, DIM_VECTOR2);
            break;
        
        case 7:
            ejercicioCalcularModaDeUnVector(vector,util_vector);
            break;

        case 8:
            ejercicioOrdenarDosVectoresOrdenados(vector, vector2, util_vector, util_vector2, DIM_VECTOR, DIM_VECTOR2);
            break;

        case -1:
            RealizarBusquedaSecuencial(vector, util_vector);
            break;

        case -2:
            controladorOrdenarSeleccion(vector,util_vector);
            break;

        case -3:
            controladorOrdenarPorInsercion(vector, util_vector);
            break;

        case -4:
            controladorMetodoBurbuja(vector, util_vector);
            break;

        default:
            cout<<"Opción no valida, introduzca otro numero:"<<endl;
            seleccionEjercicioaRealizar(vector,util_vector, DIM_VECTOR, vector2, util_vector2, DIM_VECTOR2);
    }
}

void copiarVectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){
    //reinicio util del vector2
    util_vector2=0;
    for(int i=0; i<util_vector1 && i < DIM_VECTOR2; i++){

        vector2[i]=vector1[i];
        util_vector2=util_vector2+1;
    }

}

void copiarPares(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    bool esPar;

    for(int i=0; i<util_vector1 && i < DIM_VECTOR2; i++){

        esPar=esElementoVectorPar(vector1[i]);

        if(esPar==true){
            vector2[i]=vector1[i];
            util_vector2=util_vector2+1;
        }
    }
}

void copiarPrimos(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    bool primo;

    for(int i=0; i<util_vector1 && i < DIM_VECTOR2; i++){

        primo=calculoPrimo(vector1[i]);
        if(primo==true){
            
            vector2[util_vector2]=vector1[i];
            util_vector2++;
        }
    }
}


void agregarNuevoEnteroenVectorEnteros(int vector[], int &util_vector, const int DIM_VECTOR, int entero){

    int n=0;
    cin>>n;

    vector[util_vector]=n;

    util_vector++;
}

bool hayEspacio(int &util_vector, const int DIM_VECTOR) {

    bool espacio=false;
    if(util_vector<=DIM_VECTOR){

        espacio=true;
    }

    return espacio;
}

bool esElementoVectorPar(int numero){

    bool esPar;

    if(numero%2 == 0){
        esPar=true ;
    } 

    else{
        esPar=false;
    }

    return esPar;
}

bool calculoPrimo (int numero) {

    int divisor;
    bool esprimo=true; 
    for (divisor=2 ; divisor <numero; ++divisor ){

        if ( numero%divisor == 0) {
            esprimo = false; 
        }
    }

    return esprimo; 
}

void ejercicioAgregarEntero(int vector[],int &util_vector, const int DIM_VECTOR) {

    bool espacio;
    imprimeVectorEnteros(vector, util_vector); //{4,2,7}
    doblarValoresDelVectorEnteros(vector, util_vector);
    imprimeVectorEnteros(vector, util_vector); //{8,4,14}3
    espacio=hayEspacio(util_vector, DIM_VECTOR);

    if (espacio==true){
        agregarNuevoEnteroenVectorEnteros(vector,util_vector, DIM_VECTOR, -1);
        imprimeVectorEnteros(vector, util_vector);
    }
}

void imprimeVectorEnteros(const int vector[], int util_vector){
    cout << "Vector Enteros = { ";
    for (int i=0; i < util_vector; i++){
        cout << vector[i] << " ";
    }
    cout << "}" << endl;
}


void doblarValoresDelVectorEnteros(int vector[], int util_vector){
    cout << USER << "Doblando el valor del contenido de las componentes del vector, por favor tenga paciencia..." << RESTORE << endl;
    //cout << DEBUG << "debug: El valor de las utiles antes del bucle es: " << util_vector << RESTORE <<  endl;
    for (int i=0; i < util_vector; i++){
      //  cout << DEBUG << "debug: Entrada en el bucle para doblar valores del vector..." << RESTORE << endl;
        vector[i]  = 2 * vector[i];
    }
    cout << USER << "Se dobló correctamente el vector... Lo comprobará cuando vuelva a imprimirlo..." << RESTORE << endl;
}

void ejercicioCopiarVectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    imprimeVectorEnteros(vector1, util_vector1);

    if(util_vector1>DIM_VECTOR2){

        cout<<"Se realizará la copia, pero es posible que se pierdan algunos enteros"<<endl;
        copiarVectores(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);
    }

    else if (util_vector1<=DIM_VECTOR2){

        copiarVectores(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);
    }

    imprimeVectorEnteros(vector2, util_vector2);
}

void ejercicioCopiarPares(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    imprimeVectorEnteros(vector1, util_vector1);

    if(util_vector1>DIM_VECTOR2){

        cout<<"Se realizará la copia, pero es posible que se pierdan algunos enteros"<<endl;
        copiarPares(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);
    }

    else if (util_vector1<=DIM_VECTOR2){

        copiarPares(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);
    }

    imprimeVectorEnteros(vector2, util_vector2);
}

void ejercicioCopiarPrimos(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    imprimeVectorEnteros(vector1, util_vector1);

    if(util_vector1>DIM_VECTOR2){

        cout<<"Se realizará la copia, pero es posible que se pierdan algunos enteros"<<endl;
        copiarPrimos(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);
    }

    else if (util_vector1<=DIM_VECTOR2){

        copiarPrimos(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);
    }

    imprimeVectorEnteros(vector2, util_vector2);
}

void agregarEnteroAlFinalDelVector(int vector_salida[],int &util_vector_salida, int elemento_entrada){

    vector_salida[util_vector_salida] = elemento_entrada;
    util_vector_salida=util_vector_salida+1;
}

bool verificarSiElementoSeRepiteContiguamente(int n, int m){

    bool seRepite;

        if (n != m ){
            seRepite=false;
        }
        else {
            seRepite=true;
        }

    return seRepite;
}


void eliminaElementosRepetidosContiguamenteDeUnVector(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    int i=0;

    if (util_vector1 > 0) {
        //Siempre se inserta el primer elemento
        if (hayEspacio(util_vector2, DIM_VECTOR2==true)){
            agregarEnteroAlFinalDelVector(vector2, util_vector2, vector1[i]);
        }
    }

    for (i=1 ; i < util_vector1; i++) {

        if ( verificarSiElementoSeRepiteContiguamente(vector1[i],vector1[i-1])==false ){
            if(hayEspacio(util_vector2, DIM_VECTOR2)==true) {
                agregarEnteroAlFinalDelVector(vector2, util_vector2, vector1[i+1]);
            }
        }
    }
}

void ejercicioEliminarRepetidosContiguos( int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2 ){


    cout<<"Vector original:"<<endl;
    imprimeVectorEnteros(vector1,util_vector1);

    eliminaElementosRepetidosContiguamenteDeUnVector(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);

    cout<<"Vector sin repetidos contiguos:"<<endl;
    imprimeVectorEnteros(vector2,util_vector2);
}

int calculoMayorEntreDosNumeros(int n, int m){
   
    int numero= m;

    if (n>m) {
        numero=n;
    }

    return numero;
}

void intercambiarDosVectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    const int DIM_VECTOR_AUX = calculoMayorEntreDosNumeros(DIM_VECTOR1,DIM_VECTOR2);
    int vector_aux[DIM_VECTOR_AUX];
    int util_vector_aux = 0;

    //Copio contenido del vector 1 al vector aux
    copiarVectores(vector1,vector_aux, util_vector1, util_vector_aux, DIM_VECTOR1, DIM_VECTOR_AUX); 
     //Copio contenido del vector 2 al vector 1
    copiarVectores(vector2,vector1, util_vector2, util_vector1, DIM_VECTOR2, DIM_VECTOR1);
     //Copio contenido del vector aux al vector 2
    copiarVectores(vector_aux,vector2, util_vector_aux, util_vector2, DIM_VECTOR_AUX, DIM_VECTOR2);

}

void ejercicioIntercambiarContenidosDOSvectores(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2 ){

    cout<<"\nVECTORES ORIGINALES:"<<endl;
    imprimeVectorEnteros(vector1,util_vector1);
    imprimeVectorEnteros(vector2,util_vector2);

    if(hayEspacio(util_vector1, DIM_VECTOR2) && hayEspacio(util_vector2, DIM_VECTOR1)==true) {
        intercambiarDosVectores(vector1,vector2, util_vector1, util_vector2,DIM_VECTOR1, DIM_VECTOR2);

        cout<<"\nVECTORES INTERCAMBIADOS:"<<endl;
        imprimeVectorEnteros(vector1,util_vector1);
        imprimeVectorEnteros(vector2,util_vector2);
    }

    else{
        cout<<"No hay espacio para realizar el intercambio."<<endl;
    } 
}

int calculoModaDeUnVector(int vector[], int &util_vector){

    int aux = vector[0];
    int moda = 0;
    int contador_moda=0;

    int contador_auxiliar_moda=0;
    
    for (int i=1; i<util_vector ; i++){

        if (vector[i]==aux) {

            contador_moda++;

            if (contador_moda>contador_auxiliar_moda){

                moda=vector[i];
            }
        }

        else if (vector[i]!=aux ){

            contador_auxiliar_moda = contador_moda;
            contador_moda=0;
            aux=vector[i];

        }
    }
    
    return moda;
}

void imprimeModa(int numero){

    cout<< "La moda del vector es { "<<numero<<" }"<<endl;
}

void ejercicioCalcularModaDeUnVector(int vector[],int  &util_vector){

    int moda=0;
    imprimeVectorEnteros( vector, util_vector);
    
    moda=calculoModaDeUnVector(vector, util_vector);

    imprimeModa(moda);
}

int busquedaSecuencialDeUnVector(int numero_a_buscar, int vector[], int &util_vector, int posicion){

    bool encontrado=false;
    bool es_igual=false;

    for(int i=0; i<util_vector; i++){

        if(vector[i]==numero_a_buscar && encontrado==false){
            es_igual=true;
            posicion= i ;
            encontrado=true;

        }
    }

    return posicion;

}

void RealizarBusquedaSecuencial(int vector[], int &util_vector){

    int numero_a_buscar;


    imprimeVectorEnteros(vector, util_vector);
    cout<<"Introduce numero a buscar:"<<endl;
    cin>>numero_a_buscar;

    int posicion=busquedaSecuencialDeUnVector(numero_a_buscar, vector, util_vector, posicion);


    cout<<"EL número "<<numero_a_buscar<<" se encuentra en la posicion: "<<posicion<<"."<<endl;
}

void ordenarDosVectoresOrdenados(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int vector_ordenado[], int &util_vector_ordenado){

    int i=0;
    int j=0;
    util_vector_ordenado = 0;

    while( i < util_vector1 && j < util_vector2 ) {
 
        if ( vector1[i] < vector2[j] ) {

            vector_ordenado[util_vector_ordenado]=vector1[i];
            i++;

        }

        else {

            vector_ordenado[util_vector_ordenado]=vector2[j];
            j++;
        }

        util_vector_ordenado++;
    }
    //Si quedan elementos en alguno de los vectores, los copiamos en el vector ordenado

    while (i < util_vector1) {
        vector_ordenado[util_vector_ordenado]= vector1[i];
        i++;
        util_vector_ordenado++;
    }
       while (j < util_vector2) {
        vector_ordenado[util_vector_ordenado]= vector2[j];
        j++;
        util_vector_ordenado++;
    }
}

void ejercicioOrdenarDosVectoresOrdenados(int vector1[], int vector2[], int &util_vector1, int &util_vector2, int DIM_VECTOR1, int DIM_VECTOR2){

    const int DIM_VECTOR_ORDENADO=100;
    int vector_ordenado[DIM_VECTOR_ORDENADO];
    int util_vector_ordenado = (util_vector1 + util_vector2);

    cout<<"Los vectores son: "<<endl;
    imprimeVectorEnteros(vector1, util_vector1);
    imprimeVectorEnteros(vector2, util_vector2);

    ordenarDosVectoresOrdenados(vector1,vector2,util_vector1,util_vector2,vector_ordenado,util_vector_ordenado);

    cout<<"El vector ordenado es:"<<endl;
    imprimeVectorEnteros(vector_ordenado, util_vector_ordenado);

}

void ordenacionSeleccion(int vector[], int &util_vector){

    int pos_min;
    int aux;

    //Bucle principal -- I
    for ( int i=0; i<util_vector - 1; i++ ){
        
        //Asigno Pablito a la posicion de I
        pos_min = i;
        
        //Bucle señor Polo
        for (int j=i+1 ; j< util_vector; j++ ){
            if(vector[j] < vector[pos_min]){
                pos_min = j ;

            }
        }
        //Intercambio de valores
        aux = vector[i];
        vector[i] = vector[pos_min];
        vector[pos_min] = aux;
    }
    
}

void ordenarPorInsercion (int vector[], int &util_vector){

    int izda; //Gabriel
    int i; //Gutierrez
    int valor;// Luna

    for ( izda=1; izda<util_vector; izda++){
        
        valor = vector[izda]; //Aqui guardo el valor a ordenar en cada iteración del bucle.

        for ( i = izda ; i > 0 && valor<vector[i-1] ; i--){
            vector[i] = vector[i-1];
        }
    vector[i] = valor;
    }

}

void controladorOrdenarSeleccion (int vector[], int &util_vector){

    cout<<"Este es el vector original."<<endl;
    imprimeVectorEnteros(vector, util_vector);

    ordenacionSeleccion(vector, util_vector);

    cout<<"Este es el vector ordenado."<<endl;
    imprimeVectorEnteros(vector, util_vector);

}

void controladorOrdenarPorInsercion(int vector[], int &util_vector){

    cout<<"Este es el vector original."<<endl;
    imprimeVectorEnteros(vector, util_vector);

    ordenarPorInsercion(vector, util_vector);

    cout<<"Este es el vector ordenado."<<endl;
    imprimeVectorEnteros(vector, util_vector);

}

void ordenacionBurbuja(int vector[], int &util_vector){

    bool cambio=true;

    for (int izda=0; izda<util_vector && cambio ; izda++) {
        cambio = false;
        for (int i=util_vector - 1; i>izda ; i--){
        
            if (vector[i] < vector [i - 1]){
            cambio=true;
            
            int aux = vector [i];
            vector[i] = vector [i - 1];
            vector [i - 1]= aux;
            }
        }
    }


}

void controladorMetodoBurbuja(int vector[], int &util_vector){


    cout<<"Este es el vector original."<<endl;
    imprimeVectorEnteros(vector, util_vector);

    ordenacionBurbuja(vector, util_vector);

    cout<<"Este es el vector ordenado."<<endl;
    imprimeVectorEnteros(vector, util_vector);


}
