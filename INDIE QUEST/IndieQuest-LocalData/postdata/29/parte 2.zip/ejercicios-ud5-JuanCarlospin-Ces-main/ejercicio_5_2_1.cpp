#include <iostream>
#include <cmath>
using namespace std;

int main () {

	const int NUM_ALUMNOS = 5;
	double notas [NUM_ALUMNOS], media, desviacion_tipica, varianza;
	int contador_alumnos=0;
	//Pidiendo notas de los alumnos
	for (int i=0; i<NUM_ALUMNOS; i++) {
		
		cout << "Nota del alumno "<< i << ": ";
		cin >> notas[i];
		
		contador_alumnos=contador_alumnos+1;
	}

	//Calculando la media

	media=0 ;
	for (int i=0; i<NUM_ALUMNOS;i++) {
		media += notas[i];
	}

	media /= NUM_ALUMNOS;


	//Calculo de la desviación típica

	desviacion_tipica= sqrt( ( pow(contador_alumnos,2) / NUM_ALUMNOS  ) - pow(media,2) ) ;

	//Calculo de la varianza

	varianza = pow( desviacion_tipica , 2) ;

	//Imprimiendo Resultados


	cout <<"\nMedia de las notas es= "<< media << endl;
	cout <<"Desviación tipica: "<<desviacion_tipica <<endl;
	cout <<"Varianza: "<<varianza<<endl;

}