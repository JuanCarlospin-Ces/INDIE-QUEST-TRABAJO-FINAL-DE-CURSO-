#include <iostream>
using namespace std;

int main() {

	const int DIM_VECTORES=10;
	int v1[DIM_VECTORES], v2[DIM_VECTORES];
	int util_vectores=0;
	int total_valores=0;

	//Pido numero de valores
	cout<<"Introduce numero total valores: (MAXIMO: "<<DIM_VECTORES<<" )"<<endl;
	do {
		cin>>total_valores;
	}while (total_valores < 0 || total_valores > DIM_VECTORES) ;

	//Introducen valores
	cout<<"Ahora introduzca los valores deseados: "<<endl;
	for (int i=0; i<total_valores; i++){
		cin>> v1[util_vectores];
		util_vectores++;
	} 

	//Cambio valores

	for (int i=0; i<util_vectores ; i++) {

		v2[i]=v1[i];
	}

	//Imprimo valores
	
	cout<<"Los valorses son: ";

	for (int i=0; i<util_vectores; i++) {
		cout<< v2[i]<<" ";
	}
	cout<<"\n"<<endl;
}