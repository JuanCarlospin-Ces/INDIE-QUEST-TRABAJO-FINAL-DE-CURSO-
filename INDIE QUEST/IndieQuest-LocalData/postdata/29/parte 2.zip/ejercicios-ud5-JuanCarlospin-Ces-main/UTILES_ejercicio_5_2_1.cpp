#include <iostream>
#include <cmath>
using namespace std;

int main () {

	const int DIM_NOTAS = 5;
	double notas [DIM_NOTAS], media, desviacion_tipica, varianza;
	int util_notas=0, i=0;
	int soldados_de_pie;

	do {
		cout<<"¿Cuantos soldados aún están de pie? (MAXIMO: "<<DIM_NOTAS<<")"<<endl;
		cin>>soldados_de_pie;

	} while (soldados_de_pie<=0 || soldados_de_pie > DIM_NOTAS);
	//post: soldados_de_pie >0 y soldados_de_pie <= DIM_NOTAS

	//Pidiendo notas de los alumnos
	for ( i=0; i<soldados_de_pie; i++) {
		
		cout << "Nota del alumno "<< (i+1) << ": ";
		cin >> notas[util_notas];
		
		util_notas=util_notas+1;
	}
	//post: util_notas = alumnos_vivos

	//Calculando la media

	//pre DIM_NOTAS>0, util_notas
	media=0 ;
	for ( i=0; i<soldados_de_pie;i++) {
		media += notas[i];
	}

	media /= soldados_de_pie;


	//Calculo de la desviación típica

	desviacion_tipica= sqrt( ( pow( notas[util_notas-1], 2 ) / soldados_de_pie  ) - pow(media,2) ) ;

	//Calculo de la varianza

	varianza = pow( desviacion_tipica , 2) ;

	//Imprimiendo Resultados


	cout <<"\nMedia de las notas es= "<< media << endl;
	cout <<"Desviación tipica: "<<desviacion_tipica <<endl;
	cout <<"Varianza: "<<varianza<<endl;

}